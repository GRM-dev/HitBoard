#!/sbin/python2
# EASY-INSTALL-ENTRY-SCRIPT: 'livestreamer==1.7.4','console_scripts','livestreamer'
#__requires__ = 'livestreamer==1.7.4'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('livestreamer', 'console_scripts', 'livestreamer')()
    )
